<?php

$servername = "localhost";
$username = "jtflyjgn_croadz";
$password = "[Mpi37)Sy6";
$dbname = "jtflyjgn_croadz";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

?>

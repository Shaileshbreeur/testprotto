<?php

$orderid = date('Ymdhis');
echo $orderid;

?>

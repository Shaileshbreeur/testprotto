<?php

include "config.php";

$model = $_POST["model"];
$prowetoffer = "NA";
$prowetprice = "NA";
$prowetfreeoffer = "NA";
$prowetfreeprice = "NA";
$prodryoffer = "NA";
$prodryprice = "NA";

//SQL Query
$sql = "SELECT jos1n_services.offer, jos1n_services.price, jos1n_services.pass FROM jos1n_services INNER JOIN jos1n_bikes ON jos1n_services.segment = jos1n_bikes.segment WHERE jos1n_bikes.model = '$model' AND jos1n_services.type = 'ProDry'";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        $prodryprice =  $row["price"];
        $prodryoffer =  $row["offer"];
        $prodrypass =  $row["pass"];

    }
} else {
    // echo "";
}


//SQL Query
$sql = "SELECT jos1n_services.offer, jos1n_services.price, jos1n_services.pass FROM jos1n_services INNER JOIN jos1n_bikes ON jos1n_services.segment = jos1n_bikes.segment WHERE jos1n_bikes.model = '$model' AND jos1n_services.type = 'ProWet'";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        $prowetprice =  $row["price"];
        $prowetoffer =  $row["offer"];
        $prowetpass =  $row["pass"];

    }
} else {
    // echo "";
}


//SQL Query
$sql = "SELECT jos1n_services.offer, jos1n_services.price, jos1n_services.pass FROM jos1n_services INNER JOIN jos1n_bikes ON jos1n_services.segment = jos1n_bikes.segment WHERE jos1n_bikes.model = '$model' AND jos1n_services.type = 'ProWetFree'";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        $prowetfreeprice =  $row["price"];
        $prowetfreeoffer =  $row["offer"];
        $prowetfreepass =  $row["pass"];

    }
} else {
    // echo "";
}

$return_arr[] = array("prodryprice" => $prodryprice,
                    "prodryoffer" => $prodryoffer,
                    "prodrypass" => $prodrypass,
                    "prowetprice" => $prowetprice,
                    "prowetoffer" => $prowetoffer,
                    "prowetpass" => $prowetpass,
                    "prowetfreeprice" => $prowetfreeprice,
                    "prowetfreeoffer" => $prowetfreeoffer,
                    "prowetfreepass" => $prowetfreepass);

mysqli_close($conn);

echo json_encode($return_arr);

?>
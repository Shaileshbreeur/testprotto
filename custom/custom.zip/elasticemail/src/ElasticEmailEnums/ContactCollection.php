<?php
	namespace ElasticEmailEnums; 

class ContactCollection
{
    /**
     * Lists which contain the requested contact
     */
    public /*Array<\ElasticEmailEnums\ContactContainer>*/ $Lists;

    /**
     * Segments which contain the requested contact
     */
    public /*Array<\ElasticEmailEnums\ContactContainer>*/ $Segments;

}

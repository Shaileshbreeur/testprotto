<?php
	namespace ElasticEmailEnums; 

class ContactContainer
{
    /**
     * ID of the list/segment
     */
    public /*int*/ $ID;

    /**
     * Name of the list/segment
     */
    public /*string*/ $Name;

}

<?php
	namespace ElasticEmailEnums; 

class ExportLink
{
    /**
     * Direct URL to the exported file
     */
    public /*string*/ $Link;

}

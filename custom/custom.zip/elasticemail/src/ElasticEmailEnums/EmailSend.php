<?php
	namespace ElasticEmailEnums; 

class EmailSend
{
    /**
     * ID number of transaction
     */
    public /*string*/ $TransactionID;

    /**
     * Unique identifier for this email.
     */
    public /*string*/ $MessageID;

}

<?php
	namespace ElasticEmailEnums; 

class TemplateList
{
    /**
     * List of templates
     */
    public /*Array<\ElasticEmailEnums\Template>*/ $Templates;

    /**
     * List of draft templates
     */
    public /*Array<\ElasticEmailEnums\Template>*/ $DraftTemplate;

}

<?php
	namespace ElasticEmailEnums; 

class ContactUnsubscribeReasonCounts
{
    /**
     * 
     */
    public /*long*/ $Unknown;

    /**
     * 
     */
    public /*long*/ $NoLongerWant;

    /**
     * 
     */
    public /*long*/ $IrrelevantContent;

    /**
     * 
     */
    public /*long*/ $TooFrequent;

    /**
     * 
     */
    public /*long*/ $NeverConsented;

    /**
     * 
     */
    public /*long*/ $DeceptiveContent;

    /**
     * 
     */
    public /*long*/ $AbuseReported;

    /**
     * 
     */
    public /*long*/ $ThirdParty;

    /**
     * 
     */
    public /*long*/ $ListUnsubscribe;

}

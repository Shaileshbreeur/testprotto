<?php

$mobile = $_GET["mobile"];

echo "Your Referral Code is " . strtoupper(dechex($mobile));

?>